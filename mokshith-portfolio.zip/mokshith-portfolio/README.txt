MOKSHITH R — PORTFOLIO WEBSITE

Preview:
- Open index.html in a browser.

Publish it so anyone with the link can open it:
1. Go to https://app.netlify.com/drop
2. Sign in or create a Netlify account.
3. Drag the unzipped folder containing index.html onto the deploy area.
4. Netlify will publish the site and give you a public URL you can share.

You can also host this folder with GitHub Pages.

Privacy:
- The public page intentionally does not display the phone number. For a public portfolio, email and LinkedIn are safer contact options, especially while you are a student.
- Check all details and links before publishing.
